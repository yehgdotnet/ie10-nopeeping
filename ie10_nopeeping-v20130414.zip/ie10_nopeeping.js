/*
IE 10 -  Client-side protection from Password Revelation Button 
The JavaScript Approach (Works in all IE 10 document modes) 
License under GPL v2

(c) YGN Ethical Hacker Group, http://yehg.net/
*/


/*
	@param: password_id = element id of password input type 
	@html: <input type="password" id="passwd" />
	@code: 
	np = IE10_NOPEEPING;
	np.main('passwd');
*/
var IE10_NOPEEPING = {
  password_value: '',
  y_asterisks: function(times){
	as  = '';
	for(i=0;i<times-1;i++){
		as += '*';
	}
	return as;
  },
  y_removelast: function(){
	if (IE10_NOPEEPING.password_value.length>0){
		IE10_NOPEEPING.password_value = IE10_NOPEEPING.password_value.substring(0,IE10_NOPEEPING.password_value.length-1);
		// we print password value out if there is place holder
		if (typeof($("#y_place_holder")!= "undefined")){
			$("#y_place_holder").text(IE10_NOPEEPING.password_value);
		}
	}
  },
  y_scramble: function(s){	
	if (s!=""){
		ns = String.fromCharCode(s);
		IE10_NOPEEPING.password_value+=ns;
	}
	// we print password value out if there is place holder
	if (typeof($("#y_place_holder")!= "undefined")){
		$("#y_place_holder").text(IE10_NOPEEPING.password_value);
	}
  },
  y_reset_stat: function() {
	IE10_NOPEEPING.password_value = '';
	if (typeof($("#y_place_holder")!= "undefined")){
		$("#y_place_holder").text('');
	}	
  },
  init: function(password_id){
			$("#"+password_id).keypress(function(event) {					
				switch(event.which){
					case 13:
						event.preventDefault();
					break;
					case 8:
						IE10_NOPEEPING.y_removelast();
					break;
					default:
						IE10_NOPEEPING.y_scramble(event.keyCode);
					break;
				}
			   
			});
			$("#"+password_id).keydown(function(event) {
				switch(event.which){
					case 13:
						event.preventDefault();
					break;
					case 8:
						IE10_NOPEEPING.y_removelast();
					break;
					// if user selects and deletes all password text in event of wrong password (CTRL + A + DELETE) 
					// we reset our globlal password 							
					case 46: 
						IE10_NOPEEPING.y_reset_stat();
					break;
					default:
						
					break;
				}
			});		
			$("#"+password_id).focus(function(){
				y_int = setInterval(function(){
							$("#"+password_id).val(IE10_NOPEEPING.y_asterisks( $("#"+password_id).val().length+1)); 
					},300);	
			});
			$("#"+password_id).blur(function(){
				clearInterval(y_int);	
			});
  }
}